using System.Reflection;
[assembly: AssemblyTitle("AutoCivil")]
[assembly: AssemblyProduct("AutoCivil")]
[assembly: AssemblyCompany("AutoRevit")]
[assembly: AssemblyDescription("Liga o Claude no Civil 3D")]
[assembly: AssemblyCopyright("AutoRevit 2026")]
[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]
