# AutoCivil (código)

App de Windows (.NET Framework 4.8, um .exe só, sem login, sem administrador) que liga o Claude Desktop no Civil 3D 2025–2027.
Conexão: [Civil3D-mcp](https://github.com/SimsUDS/Civil3D-mcp) (MIT). O servidor Node pré-compilado fica na release v2.0.0 (servidor.zip.part0..2).

- `Program.cs` — telas (início, instalando, pronto, diagnóstico) e verificações.
- `completo.ps1` — o instalador de verdade (vai embutido; roda escondido com `C3D_GUI=1`).
- `fontes/` — Geist e Geist Mono (licença OFL, `fontes/OFL.txt`).
- `compilar.sh` — compila com Mono (`mcs -sdk:4.8`). No Windows também dá com o csc do .NET Framework, com as mesmas referências e recursos.
- Prévia das telas sem instalar: variável `AUTOCIVIL_PREVIA=pronto|diag|inst`.

Pastas no PC do usuário: `%LOCALAPPDATA%\Civil3D-IA` (Node, .NET, servidor, app, autocivil.log) e `%APPDATA%\Autodesk\ApplicationPlugins\Civil3DIA.bundle` (plugin). Porta 8091 (variável de usuário `CIVIL3D_MCP_PORT`). Relatório: `%TEMP%\instalador-civil3d-ia.log`.
