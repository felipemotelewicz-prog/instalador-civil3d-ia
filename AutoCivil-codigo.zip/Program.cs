// AutoCivil — liga o Claude Desktop no Civil 3D (modelo AutoRevit, sem login)
// Compilar (nuvem): mcs -sdk:4.8 ... (ver compilar.sh)
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace AutoCivil
{
    internal static class Program
    {
        public const string Versao = "3.0.0";

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += (s, e) => Log.Gravar("ERRO TELA: " + e.Exception);
            Log.Gravar("AutoCivil " + Versao + " aberto");
            Application.Run(new Janela());
        }
    }

    // ------------------------------------------------------------------ log
    internal static class Log
    {
        public static readonly string Pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Civil3D-IA");
        public static readonly string Arquivo = Path.Combine(Path.GetTempPath(), "instalador-civil3d-ia.log");
        public static readonly string ArquivoApp = Path.Combine(Pasta, "autocivil.log");
        public static void Gravar(string t)
        {
            try { Directory.CreateDirectory(Pasta); File.AppendAllText(ArquivoApp, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + t + Environment.NewLine); } catch { }
        }
    }

    // ------------------------------------------------------------------ tema
    internal static class Tema
    {
        public static readonly Color Fundo = Color.FromArgb(0, 0, 0);
        public static readonly Color Cartao = Color.FromArgb(10, 10, 10);
        public static readonly Color CartaoHover = Color.FromArgb(17, 17, 17);
        public static readonly Color Texto = Color.FromArgb(237, 237, 237);
        public static readonly Color Apoio = Color.FromArgb(161, 161, 161);
        public static readonly Color Apagado = Color.FromArgb(102, 102, 102);
        public static readonly Color Borda = Color.FromArgb(35, 35, 35);
        public static readonly Color Borda2 = Color.FromArgb(46, 46, 46);
        public static readonly Color Azul = Color.FromArgb(124, 184, 230);
        public static readonly Color Verde = Color.FromArgb(74, 222, 128);
        public static readonly Color Amarelo = Color.FromArgb(250, 204, 21);
        public static readonly Color Vermelho = Color.FromArgb(248, 113, 113);

        private static readonly PrivateFontCollection Colecao = new PrivateFontCollection();
        private static readonly Dictionary<string, FontFamily> Familias = new Dictionary<string, FontFamily>();

        [DllImport("gdi32.dll")]
        private static extern IntPtr AddFontMemResourceEx(IntPtr pbFont, uint cbFont, IntPtr pdv, ref uint pcFonts);

        static Tema()
        {
            foreach (var nome in new[] { "Geist-Regular.ttf", "Geist-Light.ttf", "GeistMono-Regular.ttf" })
            {
                try
                {
                    using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(nome))
                    {
                        if (s == null) continue;
                        var dados = new byte[s.Length];
                        s.Read(dados, 0, dados.Length);
                        var p = Marshal.AllocCoTaskMem(dados.Length);
                        Marshal.Copy(dados, 0, p, dados.Length);
                        Colecao.AddMemoryFont(p, dados.Length);
                        try { uint n = 0; AddFontMemResourceEx(p, (uint)dados.Length, IntPtr.Zero, ref n); } catch { }
                    }
                }
                catch (Exception ex) { Log.Gravar("fonte " + nome + ": " + ex.Message); }
            }
            try { foreach (var f in Colecao.Families) Familias[f.Name] = f; } catch { }
        }

        private static bool Testar(Font f) { try { return f.Height > 0; } catch { return false; } }

        private static Font Criar(string nome, float tam, params string[] planoB)
        {
            FontFamily fam;
            if (Familias.TryGetValue(nome, out fam))
            {
                try { var f = new Font(fam, tam, FontStyle.Regular, GraphicsUnit.Point); if (Testar(f)) return f; } catch { }
            }
            foreach (var n in new[] { nome }.Concat(planoB))
            {
                try { var f = new Font(n, tam, FontStyle.Regular, GraphicsUnit.Point); if (Testar(f) && f.Name == n) return f; } catch { }
            }
            return new Font("Segoe UI", tam);
        }

        public static Font Sans(float t) { return Criar("Geist", t, "Segoe UI"); }
        public static Font Leve(float t) { return Criar("Geist Light", t, "Geist", "Segoe UI Light", "Segoe UI"); }
        public static Font Mono(float t) { return Criar("Geist Mono", t, "Cascadia Mono", "Consolas"); }

        public static Size Medir(string texto, Font f, int largura = 0)
        {
            if (largura <= 0) return TextRenderer.MeasureText(texto, f, Size.Empty, TextFormatFlags.NoPadding);
            return TextRenderer.MeasureText(texto, f, new Size(largura, int.MaxValue), TextFormatFlags.NoPadding | TextFormatFlags.WordBreak);
        }

        public static GraphicsPath Arredondado(Rectangle r, int raio)
        {
            var p = new GraphicsPath();
            int d = raio * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    // ------------------------------------------------------------------ controles
    internal class Texto : Control
    {
        public Color Cor = Tema.Texto;
        public bool Quebra = true;
        public Texto(string t, Font f, Color cor, int largura)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Font = f; Cor = cor; base.Text = t; Width = largura; Ajustar();
        }
        public void Trocar(string t, Color? cor = null) { base.Text = t; if (cor.HasValue) Cor = cor.Value; Ajustar(); Invalidate(); }
        public void Ajustar() { var s = Tema.Medir(Text, Font, Width - 3); Height = s.Height + 2; }
        protected override void OnPaint(PaintEventArgs e)
        {
            TextRenderer.DrawText(e.Graphics, Text, Font, new Rectangle(2, 0, Width - 3, Height), Cor, TextFormatFlags.NoPadding | TextFormatFlags.WordBreak);
        }
    }

    internal sealed class Botao : Control
    {
        public bool Primario = true;
        private bool _hover;
        public Botao(string t, bool primario, Font f)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Primario = primario; Font = f; Text = t; Cursor = Cursors.Hand;
            var s = Tema.Medir(t, f); Size = new Size(s.Width + 40, s.Height + 22);
        }
        public void Trocar(string t) { Text = t; var s = Tema.Medir(t, Font); Width = s.Width + 40; Invalidate(); }
        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(0, 0, Width - 1, Height - 1);
            Color fundo, letra;
            if (!Enabled) { fundo = Tema.Borda; letra = Tema.Apagado; }
            else if (Primario) { fundo = _hover ? Color.FromArgb(204, 204, 204) : Tema.Texto; letra = Color.Black; }
            else { fundo = _hover ? Tema.CartaoHover : Tema.Cartao; letra = Tema.Texto; }
            using (var p = Tema.Arredondado(r, 6))
            {
                using (var b = new SolidBrush(fundo)) g.FillPath(b, p);
                if (!Primario) using (var pen = new Pen(Tema.Borda2)) g.DrawPath(pen, p);
            }
            TextRenderer.DrawText(g, Text, Font, ClientRectangle, letra, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }

    internal sealed class Moldura : Panel
    {
        public Moldura()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Tema.Fundo;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var p = Tema.Arredondado(new Rectangle(0, 0, Width - 1, Height - 1), 10))
            {
                using (var b = new SolidBrush(Tema.Cartao)) g.FillPath(b, p);
                using (var pen = new Pen(Tema.Borda)) g.DrawPath(pen, p);
            }
        }
    }

    // Bolinha de status: 0 cinza, 1 andando (azul), 2 ok (verde), 3 aviso (amarelo), 4 erro (vermelho)
    internal sealed class Ponto : Control
    {
        private int _estado;
        public int Estado { get { return _estado; } set { _estado = value; Invalidate(); } }
        public Ponto()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; Size = new Size(16, 16);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(3, 3, 10, 10);
            switch (_estado)
            {
                case 0: using (var p = new Pen(Tema.Apagado, 1.2f)) g.DrawEllipse(p, r); break;
                case 1: using (var p = new Pen(Tema.Azul, 1.6f)) g.DrawEllipse(p, r); using (var b = new SolidBrush(Tema.Azul)) g.FillEllipse(b, 6, 6, 4, 4); break;
                case 2: using (var p = new Pen(Tema.Verde, 1.8f)) { g.DrawLines(p, new[] { new PointF(4, 8.5f), new PointF(7, 11.5f), new PointF(12.5f, 4.5f) }); } break;
                case 3: using (var b = new SolidBrush(Tema.Amarelo)) g.FillEllipse(b, r); break;
                default: using (var p = new Pen(Tema.Vermelho, 1.8f)) { g.DrawLine(p, 4.5f, 4.5f, 11.5f, 11.5f); g.DrawLine(p, 11.5f, 4.5f, 4.5f, 11.5f); } break;
            }
        }
    }

    internal sealed class Barra : Control
    {
        private int _v;
        public int Valor { get { return _v; } set { _v = Math.Max(0, Math.Min(100, value)); Invalidate(); } }
        public Barra() { SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); Height = 3; }
        protected override void OnPaint(PaintEventArgs e)
        {
            using (var b = new SolidBrush(Tema.Borda)) e.Graphics.FillRectangle(b, ClientRectangle);
            using (var b = new SolidBrush(Tema.Texto)) e.Graphics.FillRectangle(b, 0, 0, Width * _v / 100, Height);
        }
    }

    internal sealed class Icone : Control
    {
        private readonly Image _img;
        public Icone(Image img, int tam)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent; _img = img; Size = new Size(tam, tam);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            if (_img == null) return;
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            e.Graphics.DrawImage(_img, ClientRectangle);
        }
    }

    // ------------------------------------------------------------------ verificações do computador
    internal sealed class Civil
    {
        public int Ano; public string Serie = ""; public string Pasta = ""; public string Nome = "";
    }

    internal static class Sistema
    {
        public const int Porta = 8091;
        public static readonly string Raiz = Log.Pasta;
        public static readonly string Bundle = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"Autodesk\ApplicationPlugins\Civil3DIA.bundle");
        public static string Node { get { return Path.Combine(Raiz, @"node\node.exe"); } }
        public static string Index { get { return Path.Combine(Raiz, @"civil3d-mcp\build\index.js"); } }

        public static List<Civil> AcharCivil()
        {
            var lista = new List<Civil>();
            try
            {
                using (var raiz = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Autodesk\AutoCAD"))
                {
                    if (raiz != null)
                        foreach (var serie in raiz.GetSubKeyNames())
                            using (var ks = raiz.OpenSubKey(serie))
                            {
                                if (ks == null) continue;
                                foreach (var prod in ks.GetSubKeyNames())
                                    using (var kp = ks.OpenSubKey(prod))
                                    {
                                        if (kp == null) continue;
                                        var nome = kp.GetValue("ProductName") as string ?? "";
                                        var pasta = (kp.GetValue("AcadLocation") as string ?? "").TrimEnd('\\');
                                        if (nome.IndexOf("Civil 3D", StringComparison.OrdinalIgnoreCase) < 0 || pasta == "") continue;
                                        if (!File.Exists(Path.Combine(pasta, @"C3D\AeccDbMgd.dll"))) continue;
                                        var m = Regex.Match(nome + " " + pasta, "20\\d\\d");
                                        if (!m.Success) continue;
                                        lista.Add(new Civil { Ano = int.Parse(m.Value), Serie = serie, Pasta = pasta, Nome = "Civil 3D " + m.Value });
                                    }
                            }
                }
            }
            catch (Exception ex) { Log.Gravar("registro: " + ex.Message); }
            if (lista.Count == 0)
            {
                try
                {
                    var pf = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Autodesk");
                    if (Directory.Exists(pf))
                        foreach (var d in Directory.GetDirectories(pf, "AutoCAD 20*"))
                            if (File.Exists(Path.Combine(d, @"C3D\AeccDbMgd.dll")))
                            {
                                int ano = int.Parse(Regex.Match(Path.GetFileName(d), "20\\d\\d").Value);
                                lista.Add(new Civil { Ano = ano, Pasta = d, Nome = "Civil 3D " + ano });
                            }
                }
                catch { }
            }
            return lista.GroupBy(c => c.Ano).Select(g => g.First()).OrderBy(c => c.Ano).ToList();
        }

        public static bool CivilAberto() { try { return Process.GetProcessesByName("acad").Length > 0; } catch { return false; } }

        public static List<string> PastasConfig(bool criar)
        {
            var l = new List<string>();
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            try
            {
                var pk = Path.Combine(local, "Packages");
                if (Directory.Exists(pk))
                    foreach (var d in Directory.GetDirectories(pk, "Claude_*"))
                    {
                        var c = Path.Combine(d, @"LocalCache\Roaming\Claude");
                        if (Directory.Exists(c)) l.Add(c);
                    }
            }
            catch { }
            try
            {
                var cd = Path.Combine(local, "Claude-Data");
                if (Directory.Exists(cd)) l.AddRange(Directory.GetDirectories(cd, "claude_*"));
            }
            catch { }
            var ap = Path.Combine(roaming, "Claude");
            if (Directory.Exists(ap)) l.Add(ap);
            if (l.Count == 0 && criar) { Directory.CreateDirectory(ap); l.Add(ap); }
            return l.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static bool ClaudeInstalado()
        {
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (File.Exists(Path.Combine(local, @"AnthropicClaude\claude.exe"))) return true;
            if (PastasConfig(false).Count > 0) return true;
            try { return Directory.GetDirectories(Path.Combine(local, "Packages"), "Claude_*").Length > 0; } catch { return false; }
        }

        // Lê cada config. Devolve: caminho -> (null se JSON quebrado) objeto.
        public static Dictionary<string, Dictionary<string, object>> LerConfigs(out List<string> quebrados)
        {
            quebrados = new List<string>();
            var r = new Dictionary<string, Dictionary<string, object>>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in PastasConfig(false))
            {
                var arq = Path.Combine(p, "claude_desktop_config.json");
                if (!File.Exists(arq)) continue;
                try
                {
                    var txt = File.ReadAllText(arq);
                    var obj = string.IsNullOrWhiteSpace(txt) ? new Dictionary<string, object>() : new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(txt);
                    r[arq] = obj ?? new Dictionary<string, object>();
                }
                catch { quebrados.Add(arq); }
            }
            return r;
        }

        public static bool ConfigTemCivil(Dictionary<string, object> cfg)
        {
            object ms; if (!cfg.TryGetValue("mcpServers", out ms)) return false;
            var d = ms as Dictionary<string, object>; if (d == null || !d.ContainsKey("civil3d")) return false;
            var s = d["civil3d"] as Dictionary<string, object>; if (s == null) return false;
            object cmd; return s.TryGetValue("command", out cmd) && cmd is string && File.Exists((string)cmd);
        }

        // Grava o bloco civil3d em todas as cópias do config (com backup, sem mexer nos outros servidores).
        public static int GravarConfig(List<string> erros)
        {
            int n = 0;
            var ser = new JavaScriptSerializer();
            foreach (var p in PastasConfig(true))
            {
                var arq = Path.Combine(p, "claude_desktop_config.json");
                try
                {
                    Dictionary<string, object> cfg = new Dictionary<string, object>();
                    if (File.Exists(arq))
                    {
                        File.Copy(arq, arq + ".bak-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true);
                        var txt = File.ReadAllText(arq);
                        if (!string.IsNullOrWhiteSpace(txt)) cfg = ser.Deserialize<Dictionary<string, object>>(txt) ?? cfg;
                    }
                    object ms;
                    var servidores = (cfg.TryGetValue("mcpServers", out ms) ? ms as Dictionary<string, object> : null) ?? new Dictionary<string, object>();
                    servidores["civil3d"] = new Dictionary<string, object>
                    {
                        { "command", Node },
                        { "args", new[] { Index } },
                        { "env", new Dictionary<string, object> { { "CIVIL3D_HOST", "127.0.0.1" }, { "CIVIL3D_PORT", Porta.ToString() }, { "MCP_HTTP_PORT", "3091" } } }
                    };
                    cfg["mcpServers"] = servidores;
                    File.WriteAllText(arq, Bonito(ser.Serialize(cfg)), new UTF8Encoding(false));
                    n++;
                }
                catch (Exception ex) { erros.Add(arq + ": " + ex.Message); }
            }
            return n;
        }

        // Deixa o JSON legível (2 espaços), sem mudar o conteúdo.
        public static string Bonito(string json)
        {
            var sb = new StringBuilder(); int nivel = 0; bool str = false;
            for (int i = 0; i < json.Length; i++)
            {
                char c = json[i];
                if (c == '"' && (i == 0 || json[i - 1] != '\\' || (i > 1 && json[i - 2] == '\\'))) str = !str;
                if (str) { sb.Append(c); continue; }
                switch (c)
                {
                    case '{': case '[': sb.Append(c).Append('\n').Append(new string(' ', ++nivel * 2)); break;
                    case '}': case ']': sb.Append('\n').Append(new string(' ', --nivel * 2)).Append(c); break;
                    case ',': sb.Append(c).Append('\n').Append(new string(' ', nivel * 2)); break;
                    case ':': sb.Append(": "); break;
                    default: sb.Append(c); break;
                }
            }
            return Regex.Replace(sb.ToString(), "\\{\\s*\\}", "{}").Replace("[\n" + "", "[\n");
        }

        public static bool PortaAberta(int porta)
        {
            try
            {
                using (var c = new TcpClient())
                {
                    var t = c.BeginConnect("127.0.0.1", porta, null, null);
                    bool ok = t.AsyncWaitHandle.WaitOne(600) && c.Connected;
                    try { c.EndConnect(t); } catch { }
                    return ok;
                }
            }
            catch { return false; }
        }

        public static string CaminhoClaude()
        {
            try
            {
                foreach (var p in Process.GetProcessesByName("claude"))
                {
                    try
                    {
                        var f = p.MainModule.FileName;
                        if (Regex.IsMatch(f, @"WindowsApps\\Claude_|AnthropicClaude|\\Programs\\Claude", RegexOptions.IgnoreCase)) return f;
                    }
                    catch { }
                }
            }
            catch { }
            return "";
        }

        public static void FecharClaude()
        {
            foreach (var p in Process.GetProcessesByName("claude"))
            {
                try
                {
                    var f = p.MainModule.FileName;
                    if (Regex.IsMatch(f, @"WindowsApps\\Claude_|AnthropicClaude|\\Programs\\Claude", RegexOptions.IgnoreCase)) p.Kill();
                }
                catch { }
            }
        }

        public static void AbrirClaude(string caminho)
        {
            try
            {
                if (!string.IsNullOrEmpty(caminho) && File.Exists(caminho) && caminho.IndexOf("WindowsApps", StringComparison.OrdinalIgnoreCase) < 0) { Process.Start(caminho); return; }
                var local = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"AnthropicClaude\claude.exe");
                if (File.Exists(local)) { Process.Start(local); return; }
                Process.Start("explorer.exe", @"shell:AppsFolder\Claude_pzs8sxrjxfjjc!Claude");
            }
            catch (Exception ex) { Log.Gravar("abrir claude: " + ex.Message); }
        }

        // Copia o app para a pasta dele e cria atalho no menu Iniciar (sem administrador).
        public static void InstalarApp()
        {
            try
            {
                Directory.CreateDirectory(Raiz);
                var atual = Assembly.GetExecutingAssembly().Location;
                var destino = Path.Combine(Raiz, "AutoCivil.exe");
                if (!string.Equals(Path.GetFullPath(atual), Path.GetFullPath(destino), StringComparison.OrdinalIgnoreCase)) File.Copy(atual, destino, true);
                var menu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "AutoCivil.lnk");
                var tipo = Type.GetTypeFromProgID("WScript.Shell");
                if (tipo == null) return;
                var sh = Activator.CreateInstance(tipo);
                var lnk = tipo.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { menu });
                var lt = lnk.GetType();
                lt.InvokeMember("TargetPath", BindingFlags.SetProperty, null, lnk, new object[] { destino });
                lt.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, lnk, new object[] { Raiz });
                lt.InvokeMember("Description", BindingFlags.SetProperty, null, lnk, new object[] { "AutoCivil — Claude no Civil 3D" });
                lt.InvokeMember("Save", BindingFlags.InvokeMethod, null, lnk, null);
            }
            catch (Exception ex) { Log.Gravar("instalar app: " + ex.Message); }
        }
    }

    // ------------------------------------------------------------------ janela
    internal sealed class Janela : Form
    {
        private const int L = 960, M = 48, Larg = L - 2 * M;
        private readonly Panel _corpo;
        private Panel _tela;
        private Image _logo;

        private static readonly string[] Etapas =
        {
            "Procurando o Civil 3D",
            "Node.js (o motor da conexão)",
            ".NET SDK (monta o plugin)",
            "Baixando a conexão (180+ ferramentas)",
            "Montando o plugin para o seu Civil 3D",
            "Plugin abrindo junto com o Civil 3D",
            "Configurando o Claude",
            "Finalizando"
        };

        [DllImport("dwmapi.dll")] private static extern int DwmSetWindowAttribute(IntPtr h, int a, ref int v, int s);
        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)] private static extern int SetWindowTheme(IntPtr h, string a, string i);

        public Janela()
        {
            Text = "AutoCivil";
            AutoScaleMode = AutoScaleMode.None;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Tema.Fundo; ForeColor = Tema.Texto;
            Font = Tema.Sans(9.75f);
            ClientSize = new Size(L, 700);
            try { using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("autocivil.ico")) if (s != null) Icon = new Icon(s); }
            catch (Exception ex) { Log.Gravar("icone: " + ex.Message); }
            try { using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("logo.png")) if (s != null) using (var img = Image.FromStream(s)) _logo = new Bitmap(img); }
            catch (Exception ex) { Log.Gravar("logo: " + ex.Message); }

            // topo fixo
            var topo = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = Tema.Fundo };
            topo.Paint += (s, e) => { using (var p = new Pen(Tema.Borda)) e.Graphics.DrawLine(p, 0, topo.Height - 1, topo.Width, topo.Height - 1); };
            var ic = new Icone(_logo, 26) { Location = new Point(M, 19) };
            topo.Controls.Add(ic);
            var nome = new Texto("AutoCivil", Tema.Sans(12.5f), Tema.Texto, 200);
            nome.Width = Tema.Medir("AutoCivil", nome.Font).Width + 8; nome.Ajustar();
            nome.Location = new Point(ic.Right + 10, 32 - nome.Height / 2);
            topo.Controls.Add(nome);
            var ver = new Texto("v" + Program.Versao, Tema.Mono(8.5f), Tema.Apagado, 120);
            ver.Width = Tema.Medir(ver.Text, ver.Font).Width + 8; ver.Ajustar();
            ver.Location = new Point(nome.Right + 8, 32 - ver.Height / 2 + 1);
            topo.Controls.Add(ver);
            var selo = new Texto("SEM LOGIN · BETA", Tema.Mono(8.5f), Tema.Apagado, 300);
            selo.Width = Tema.Medir(selo.Text, selo.Font).Width + 8; selo.Ajustar();
            selo.Location = new Point(L - M - selo.Width, 32 - selo.Height / 2 + 1);
            topo.Controls.Add(selo);

            _corpo = new Panel { Dock = DockStyle.Fill, BackColor = Tema.Fundo };
            Controls.Add(_corpo);
            Controls.Add(topo);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int sim = 1; if (DwmSetWindowAttribute(Handle, 20, ref sim, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref sim, 4); } catch { }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            var pre = Environment.GetEnvironmentVariable("AUTOCIVIL_PREVIA") ?? "";   // só para conferir as telas
            if (pre == "pronto") MostrarPronto();
            else if (pre == "diag") MostrarDiagnostico();
            else if (pre == "inst") { MostrarInicio(); InstalarPrevia(); }
            else MostrarInicio();
        }

        private void InstalarPrevia()
        {
            var t = NovaTela(); int y = 40;
            _tituloInst = Por(t, "Instalando…", Tema.Leve(28f), Tema.Texto, ref y, 10);
            Trocar(t, y);
            Instalar();
        }

        // -------- utilidades de layout em fluxo
        private Panel NovaTela()
        {
            var p = new Panel { Dock = DockStyle.Fill, BackColor = Tema.Fundo, AutoScroll = true };
            p.HandleCreated += (s, e) => { try { SetWindowTheme(p.Handle, "DarkMode_Explorer", null); } catch { } };
            return p;
        }

        private void Trocar(Panel nova, int alturaConteudo)
        {
            SuspendLayout();
            if (_tela != null) { _corpo.Controls.Remove(_tela); _tela.Dispose(); }
            _tela = nova; _corpo.Controls.Add(nova);
            AjustarAltura(alturaConteudo);
            ResumeLayout();
            Log.Gravar("tela: altura " + alturaConteudo + ", DPI " + DpiTela());
        }

        private int DpiTela() { try { using (var g = CreateGraphics()) return (int)g.DpiX; } catch { return 96; } }

        private void AjustarAltura(int conteudo)
        {
            int desejada = 64 + conteudo + 36;
            var area = Screen.FromControl(this).WorkingArea;
            int max = area.Height - (Height - ClientSize.Height) - 10;
            ClientSize = new Size(L, Math.Max(560, Math.Min(desejada, max)));
            if (Top + Height > area.Bottom) Top = Math.Max(area.Top, area.Bottom - Height);
        }

        private Texto Por(Panel tela, string t, Font f, Color cor, ref int y, int gap, int x = M, int largura = Larg)
        {
            var lb = new Texto(t, f, cor, largura) { Location = new Point(x, y) };
            tela.Controls.Add(lb); y = lb.Bottom + gap; return lb;
        }

        private Texto Rotulo(Panel tela, string t, ref int y) { return Por(tela, t.ToUpperInvariant(), Tema.Mono(8.5f), Tema.Apagado, ref y, 12); }

        // ================================================================ INÍCIO
        private Texto _stCivil, _stClaude, _stConexao, _stConfig;
        private Ponto _ptCivil, _ptClaude, _ptConexao, _ptConfig;
        private Botao _btInstalar;

        private void MostrarInicio()
        {
            var t = NovaTela(); int y = 40;
            Por(t, "Claude no seu Civil 3D", Tema.Leve(28f), Tema.Texto, ref y, 10);
            Por(t, "Instala a conexão que deixa o Claude trabalhar dentro do Civil 3D: superfícies, alinhamentos, perfis, corredores, redes de tubo, pontos, terraplenagem, quantitativos e pranchas.", Tema.Sans(10.5f), Tema.Apoio, ref y, 32, M, Larg - 120);

            Rotulo(t, "Neste computador", ref y);
            var cart = new Moldura { Location = new Point(M, y), Width = Larg };
            int cy = 18;
            Linha(cart, "Civil 3D", ref cy, out _ptCivil, out _stCivil);
            Linha(cart, "Claude para computador", ref cy, out _ptClaude, out _stClaude);
            Linha(cart, "Conexão do Civil 3D", ref cy, out _ptConexao, out _stConexao);
            Linha(cart, "Claude ligado ao Civil 3D", ref cy, out _ptConfig, out _stConfig);
            cart.Height = cy + 6; t.Controls.Add(cart); y = cart.Bottom + 32;

            _btInstalar = new Botao("Instalar", true, Tema.Sans(10.5f)) { Location = new Point(M, y), Enabled = false };
            _btInstalar.Click += (s, e) => Instalar();
            t.Controls.Add(_btInstalar);
            var erro = new Botao("Está dando erro?", false, Tema.Sans(10.5f)) { Location = new Point(_btInstalar.Right + 12, y) };
            erro.Click += (s, e) => MostrarDiagnostico();
            t.Controls.Add(erro);
            y = _btInstalar.Bottom + 18;
            Por(t, "Antes de instalar, salve seus desenhos e feche o Civil 3D. Na primeira vez leva de 3 a 6 minutos (baixa o Node.js e o .NET, só para esta conexão).", Tema.Sans(9.25f), Tema.Apagado, ref y, 0, M, Larg - 120);
            Trocar(t, y + 20);
            VerificarInicio();
        }

        private void Linha(Panel cart, string titulo, ref int cy, out Ponto pt, out Texto st)
        {
            pt = new Ponto { Location = new Point(20, cy + 2) };
            cart.Controls.Add(pt);
            var tt = new Texto(titulo, Tema.Sans(10.25f), Tema.Texto, 260) { Location = new Point(46, cy) };
            cart.Controls.Add(tt);
            st = new Texto("verificando…", Tema.Sans(10.25f), Tema.Apoio, Larg - 340) { Location = new Point(320, cy) };
            cart.Controls.Add(st);
            cy = Math.Max(tt.Bottom, st.Bottom) + 14;
        }

        private void VerificarInicio()
        {
            Task.Run(() =>
            {
                var civis = Sistema.AcharCivil();
                bool claude = Sistema.ClaudeInstalado();
                bool conexao = File.Exists(Sistema.Node) && File.Exists(Sistema.Index) && File.Exists(Path.Combine(Sistema.Bundle, "PackageContents.xml"));
                List<string> q; var cfgs = Sistema.LerConfigs(out q);
                bool ligado = cfgs.Values.Any(Sistema.ConfigTemCivil);
                BeginInvoke((Action)(() =>
                {
                    var bons = civis.Where(c => c.Ano >= 2025).ToList();
                    if (civis.Count == 0) { _ptCivil.Estado = 4; _stCivil.Trocar("não encontrado — instale o Civil 3D 2025, 2026 ou 2027", Tema.Vermelho); }
                    else if (bons.Count == 0) { _ptCivil.Estado = 4; _stCivil.Trocar(string.Join(", ", civis.Select(c => c.Nome)) + " — precisa ser 2025 ou mais novo", Tema.Vermelho); }
                    else { _ptCivil.Estado = 2; _stCivil.Trocar(string.Join(", ", bons.Select(c => c.Nome)), Tema.Apoio); }
                    if (claude) { _ptClaude.Estado = 2; _stClaude.Trocar("encontrado", Tema.Apoio); }
                    else { _ptClaude.Estado = 3; _stClaude.Trocar("não encontrado — baixe em claude.ai/download antes de instalar", Tema.Amarelo); }
                    _ptConexao.Estado = conexao ? 2 : 0; _stConexao.Trocar(conexao ? "instalada" : "ainda não instalada", Tema.Apoio);
                    _ptConfig.Estado = ligado ? 2 : 0; _stConfig.Trocar(ligado ? "sim" : "ainda não", Tema.Apoio);
                    _btInstalar.Enabled = bons.Count > 0;
                    if (conexao) _btInstalar.Trocar("Instalar de novo");
                }));
            });
        }

        // ================================================================ INSTALANDO
        private readonly List<Ponto> _pts = new List<Ponto>();
        private readonly List<Texto> _txs = new List<Texto>();
        private Texto _agora, _tituloInst, _subInst;
        private Barra _barra;
        private TextBox _log;
        private Botao _btDetalhes;
        private string _caminhoClaude = "";

        private void Instalar()
        {
            while (Sistema.CivilAberto())
            {
                var r = MessageBox.Show(this, "O Civil 3D está aberto.\n\nSalve seus desenhos, feche o programa e clique em Repetir.", "Feche o Civil 3D", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
                if (r == DialogResult.Cancel) return;
            }
            _caminhoClaude = Sistema.CaminhoClaude();
            var t = NovaTela(); int y = 40;
            _tituloInst = Por(t, "Instalando…", Tema.Leve(28f), Tema.Texto, ref y, 10);
            _subInst = Por(t, "Não feche esta janela. Na primeira vez leva de 3 a 6 minutos; algumas etapas ficam um tempo paradas, é normal.", Tema.Sans(10.5f), Tema.Apoio, ref y, 28, M, Larg - 120);

            var cart = new Moldura { Location = new Point(M, y), Width = Larg };
            int cy = 18; _pts.Clear(); _txs.Clear();
            for (int i = 0; i < Etapas.Length; i++)
            {
                var pt = new Ponto { Location = new Point(20, cy + 2) }; cart.Controls.Add(pt); _pts.Add(pt);
                var num = new Texto((i + 1).ToString("00"), Tema.Mono(8.5f), Tema.Apagado, 30) { Location = new Point(46, cy + 2) }; cart.Controls.Add(num);
                var tx = new Texto(Etapas[i], Tema.Sans(10.25f), Tema.Apagado, Larg - 120) { Location = new Point(80, cy) }; cart.Controls.Add(tx); _txs.Add(tx);
                cy = tx.Bottom + 12;
            }
            cart.Height = cy + 6; t.Controls.Add(cart); y = cart.Bottom + 22;

            _barra = new Barra { Location = new Point(M, y), Width = Larg }; t.Controls.Add(_barra); y = _barra.Bottom + 12;
            _agora = Por(t, "Começando…", Tema.Mono(8.5f), Tema.Apagado, ref y, 18);
            _btDetalhes = new Botao("Ver detalhes", false, Tema.Sans(9.5f)) { Location = new Point(M, y) };
            t.Controls.Add(_btDetalhes); y = _btDetalhes.Bottom + 12;
            var mol = new Moldura { Location = new Point(M, y), Size = new Size(Larg, 170), Visible = false, Padding = new Padding(14, 10, 6, 10) };
            _log = new TextBox
            {
                Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BorderStyle = BorderStyle.None, Dock = DockStyle.Fill,
                Font = Tema.Mono(8.5f), BackColor = Tema.Cartao, ForeColor = Tema.Apoio
            };
            _log.HandleCreated += (s, e) => { try { SetWindowTheme(_log.Handle, "DarkMode_Explorer", null); } catch { } };
            mol.Controls.Add(_log); t.Controls.Add(mol);
            int yLog = y;
            _btDetalhes.Click += (s, e) =>
            {
                mol.Visible = !mol.Visible;
                _btDetalhes.Trocar(mol.Visible ? "Esconder detalhes" : "Ver detalhes");
                AjustarAltura(mol.Visible ? yLog + mol.Height + 24 : yLog + 8);
            };
            Trocar(t, yLog + 8);
            RodarScript();
        }

        private async void RodarScript()
        {
            string script = null;
            int codigo;
            try
            {
                script = Path.Combine(Path.GetTempPath(), "autocivil-" + Guid.NewGuid().ToString("N") + ".ps1");
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("completo.ps1"))
                using (var r = new StreamReader(s, Encoding.UTF8))
                    File.WriteAllText(script, r.ReadToEnd(), new UTF8Encoding(true));
                codigo = await Task.Run(() => Rodar(script));
            }
            catch (Exception ex) { Log.Gravar("rodar: " + ex); codigo = 99; }
            try { if (script != null) File.Delete(script); } catch { }
            Log.Gravar("script terminou com código " + codigo);

            if (codigo != 0)
            {
                int i = _pts.FindIndex(p => p.Estado == 1); if (i < 0) i = 0;
                _pts[i].Estado = 4; _txs[i].Cor = Tema.Vermelho; _txs[i].Invalidate();
                _tituloInst.Trocar("Deu erro.", Tema.Texto);
                if (_subInst != null) _subInst.Trocar("Veja a mensagem em vermelho embaixo. Clique em \"Tentar de novo\", ou em \"Está dando erro?\" para o diagnóstico. Se continuar, mande o relatório para o suporte.", Tema.Apoio);
                _agora.Trocar(UltimoErro(), Tema.Vermelho);
                if (!_log.Parent.Visible) _btDetalhes.Trocar("Ver detalhes");
                var py = _btDetalhes.Top;
                var tentar = new Botao("Tentar de novo", true, Tema.Sans(10.5f)) { Location = new Point(_btDetalhes.Right + 12, py) };
                tentar.Click += (s, e) => Instalar();
                var diag = new Botao("Está dando erro?", false, Tema.Sans(10.5f)) { Location = new Point(tentar.Right + 12, py) };
                diag.Click += (s, e) => MostrarDiagnostico();
                var rel = new Botao("Abrir relatório", false, Tema.Sans(10.5f)) { Location = new Point(diag.Right + 12, py) };
                rel.Click += (s, e) => { try { Process.Start("notepad.exe", "\"" + Log.Arquivo + "\""); } catch { } };
                _tela.Controls.Add(tentar); _tela.Controls.Add(diag); _tela.Controls.Add(rel);
                return;
            }
            foreach (var p in _pts) p.Estado = 2;
            _barra.Valor = 100;
            Sistema.InstalarApp();
            MostrarPronto();
        }

        private string _ultimoErro = "";
        private string UltimoErro() { return _ultimoErro != "" ? _ultimoErro : "A instalação parou. Clique em \"Ver detalhes\" ou mande o relatório para o suporte."; }

        private int Rodar(string script)
        {
            var psi = new ProcessStartInfo
            {
                FileName = Path.Combine(Environment.SystemDirectory, @"WindowsPowerShell\v1.0\powershell.exe"),
                Arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"" + script + "\"",
                UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardOutput = true, RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
            };
            psi.EnvironmentVariables["C3D_GUI"] = "1";
            using (var p = new Process { StartInfo = psi })
            {
                p.OutputDataReceived += (s, e) => { if (e.Data != null) Linha(e.Data); };
                p.ErrorDataReceived += (s, e) => { if (e.Data != null) Linha(e.Data); };
                p.Start(); p.BeginOutputReadLine(); p.BeginErrorReadLine(); p.WaitForExit();
                return p.ExitCode;
            }
        }

        private static readonly Regex RePasso = new Regex(@"^\[(\d+)/(\d+)\]\s*(.*)$");

        private void Linha(string texto)
        {
            Log.Gravar("ps> " + texto);
            if (texto.StartsWith("##CLAUDE##")) { var c = texto.Substring(10).Trim(); if (c != "") _caminhoClaude = c; return; }
            if (texto.StartsWith("**********") || texto.StartsWith("Transcri") || texto.StartsWith("Windows PowerShell")) return;
            var limpo = texto.Trim();
            if (limpo.StartsWith("ERRO:")) _ultimoErro = limpo.Substring(5).Trim();
            BeginInvoke((Action)(() =>
            {
                var m = RePasso.Match(limpo);
                if (m.Success)
                {
                    int n = int.Parse(m.Groups[1].Value);
                    for (int i = 0; i < _pts.Count; i++)
                    {
                        _pts[i].Estado = i < n - 1 ? 2 : (i == n - 1 ? 1 : 0);
                        _txs[i].Cor = i <= n - 1 ? Tema.Texto : Tema.Apagado; _txs[i].Invalidate();
                    }
                    _barra.Valor = Math.Min(97, (int)((n - 1) * 100.0 / _pts.Count) + 3);
                }
                else if (limpo != "" && !limpo.StartsWith("====="))
                {
                    var curto = limpo.StartsWith("OK ") ? limpo.Substring(3).Trim() : limpo;
                    if (curto.Length > 110) curto = curto.Substring(0, 107) + "…";
                    _agora.Trocar(curto, limpo.StartsWith("ERRO") ? Tema.Vermelho : Tema.Apagado);
                }
                _log.AppendText(texto + Environment.NewLine);
            }));
        }

        // ================================================================ PRONTO
        private const string PedidoTeste = "Use o civil3d_health e me diga a versão do Civil 3D, o nome do desenho aberto e se a conexão está ok.";

        private void MostrarPronto()
        {
            var t = NovaTela(); int y = 40;
            Por(t, "Pronto. Falta só abrir.", Tema.Leve(28f), Tema.Texto, ref y, 10);
            Por(t, "A conexão está instalada. Siga os 3 passos abaixo para o Claude enxergar o seu Civil 3D.", Tema.Sans(10.5f), Tema.Apoio, ref y, 28, M, Larg - 120);

            var cart = new Moldura { Location = new Point(M, y), Width = Larg };
            int cy = 22;
            Passo(cart, "01", "Abra o Civil 3D com um desenho.", "Se aparecer um aviso de segurança sobre o \"Civil3DMcpPlugin\", clique em \"Sempre carregar\". Para conferir, digite C3DMCPSTATUS na linha de comando: tem que aparecer a porta " + Sistema.Porta + ".", ref cy);
            var b2y = cy;
            Passo(cart, "02", "Reinicie o Claude.", "Ele só lê as conexões quando abre.", ref cy);
            var reiniciar = new Botao("Reiniciar o Claude", true, Tema.Sans(10f));
            reiniciar.Location = new Point(Larg - 24 - reiniciar.Width, b2y - 4);
            reiniciar.Click += (s, e) =>
            {
                reiniciar.Enabled = false;
                Task.Run(() => { Sistema.FecharClaude(); System.Threading.Thread.Sleep(2500); Sistema.AbrirClaude(_caminhoClaude); })
                    .ContinueWith(_ => BeginInvoke((Action)(() => { reiniciar.Trocar("Claude reiniciado"); })));
            };
            cart.Controls.Add(reiniciar);
            Passo(cart, "03", "No Claude, cole este pedido:", "", ref cy);
            var caixa = new Moldura { Location = new Point(80, cy - 6), Width = Larg - 104 };
            var ped = new Texto(PedidoTeste, Tema.Mono(9f), Tema.Texto, caixa.Width - 150) { Location = new Point(16, 14) };
            caixa.Controls.Add(ped);
            caixa.Height = ped.Bottom + 14;
            var copiar = new Botao("Copiar", false, Tema.Sans(9.5f));
            copiar.Location = new Point(caixa.Width - 14 - copiar.Width, (caixa.Height - copiar.Height) / 2);
            copiar.Click += (s, e) => { try { Clipboard.SetText(PedidoTeste); copiar.Trocar("Copiado"); copiar.Left = caixa.Width - 14 - copiar.Width; } catch { } };
            caixa.Controls.Add(copiar);
            cart.Controls.Add(caixa);
            cy = caixa.Bottom + 22;
            cart.Height = cy; t.Controls.Add(cart); y = cart.Bottom + 28;

            var fechar = new Botao("Fechar", false, Tema.Sans(10.5f)) { Location = new Point(M, y) };
            fechar.Click += (s, e) => Close();
            t.Controls.Add(fechar);
            var diag = new Botao("Está dando erro?", false, Tema.Sans(10.5f)) { Location = new Point(fechar.Right + 12, y) };
            diag.Click += (s, e) => MostrarDiagnostico();
            t.Controls.Add(diag);
            y = fechar.Bottom + 16;
            Por(t, "O AutoCivil fica no menu Iniciar, para você abrir o diagnóstico quando precisar.", Tema.Sans(9.25f), Tema.Apagado, ref y, 0);
            Trocar(t, y + 20);
        }

        private void Passo(Panel cart, string num, string titulo, string apoio, ref int cy)
        {
            var n = new Texto(num, Tema.Mono(9f), Tema.Apagado, 30) { Location = new Point(24, cy + 2) }; cart.Controls.Add(n);
            var t = new Texto(titulo, Tema.Sans(11f), Tema.Texto, Larg - 320) { Location = new Point(80, cy) }; cart.Controls.Add(t);
            cy = t.Bottom + 6;
            if (apoio != "") { var a = new Texto(apoio, Tema.Sans(9.75f), Tema.Apoio, Larg - 320) { Location = new Point(80, cy) }; cart.Controls.Add(a); cy = a.Bottom; }
            cy += 22;
        }

        // ================================================================ DIAGNÓSTICO
        private sealed class Item
        {
            public string Titulo, Detalhe, Acao; public int Estado; public Action Consertar;
        }

        private void MostrarDiagnostico()
        {
            var t = NovaTela(); int y = 40;
            Por(t, "Diagnóstico", Tema.Leve(28f), Tema.Texto, ref y, 10);
            Por(t, "Confere cada peça da conexão. Onde tiver um botão, ele conserta sozinho.", Tema.Sans(10.5f), Tema.Apoio, ref y, 28, M, Larg - 120);
            var cart = new Moldura { Location = new Point(M, y), Width = Larg, Height = 80 };
            var carregando = new Texto("verificando…", Tema.Sans(10.25f), Tema.Apoio, 300) { Location = new Point(24, 28) };
            cart.Controls.Add(carregando);
            t.Controls.Add(cart);
            int yBot = cart.Bottom + 28;
            var voltar = new Botao("Voltar", false, Tema.Sans(10.5f)) { Location = new Point(M, yBot) };
            voltar.Click += (s, e) => MostrarInicio();
            var denovo = new Botao("Verificar de novo", false, Tema.Sans(10.5f)) { Location = new Point(voltar.Right + 12, yBot) };
            denovo.Click += (s, e) => MostrarDiagnostico();
            var rel = new Botao("Abrir relatório", false, Tema.Sans(10.5f)) { Location = new Point(denovo.Right + 12, yBot) };
            rel.Click += (s, e) => { try { Process.Start("notepad.exe", "\"" + (File.Exists(Log.Arquivo) ? Log.Arquivo : Log.ArquivoApp) + "\""); } catch { } };
            t.Controls.Add(voltar); t.Controls.Add(denovo); t.Controls.Add(rel);
            Trocar(t, voltar.Bottom + 20);

            Task.Run(() => Checar()).ContinueWith(tk => BeginInvoke((Action)(() =>
            {
                cart.Controls.Clear();
                int cy = 18;
                foreach (var it in tk.Result)
                {
                    var pt = new Ponto { Estado = it.Estado, Location = new Point(20, cy + 2) }; cart.Controls.Add(pt);
                    int largTexto = Larg - 80 - (it.Consertar != null ? 200 : 30);
                    var tt = new Texto(it.Titulo, Tema.Sans(10.25f), Tema.Texto, largTexto) { Location = new Point(46, cy) }; cart.Controls.Add(tt);
                    int baixo = tt.Bottom;
                    if (!string.IsNullOrEmpty(it.Detalhe))
                    {
                        var dd = new Texto(it.Detalhe, Tema.Sans(9.5f), it.Estado == 4 ? Tema.Vermelho : (it.Estado == 3 ? Tema.Amarelo : Tema.Apoio), largTexto) { Location = new Point(46, tt.Bottom + 3) };
                        cart.Controls.Add(dd); baixo = dd.Bottom;
                    }
                    if (it.Consertar != null)
                    {
                        var b = new Botao(it.Acao ?? "Consertar", true, Tema.Sans(9.5f));
                        b.Location = new Point(Larg - 22 - b.Width, cy - 4);
                        var acao = it.Consertar;
                        b.Click += (s, e) => { b.Enabled = false; try { acao(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, "AutoCivil"); } };
                        cart.Controls.Add(b);
                        baixo = Math.Max(baixo, b.Bottom - 4);
                    }
                    cy = baixo + 16;
                }
                cart.Height = cy + 4;
                int yb = cart.Bottom + 28;
                voltar.Top = denovo.Top = rel.Top = yb;
                AjustarAltura(voltar.Bottom + 20);
            })));
        }

        private List<Item> Checar()
        {
            var r = new List<Item>();
            var civis = Sistema.AcharCivil();
            var bons = civis.Where(c => c.Ano >= 2025).ToList();
            r.Add(civis.Count == 0
                ? new Item { Titulo = "Civil 3D instalado", Detalhe = "Não encontrei o Civil 3D neste computador.", Estado = 4 }
                : bons.Count == 0
                    ? new Item { Titulo = "Civil 3D compatível", Detalhe = string.Join(", ", civis.Select(c => c.Nome)) + ": a conexão precisa do 2025, 2026 ou 2027.", Estado = 4 }
                    : new Item { Titulo = "Civil 3D compatível", Detalhe = string.Join(", ", bons.Select(c => c.Nome)) + (bons.Any(c => c.Ano != 2026) ? " (o autor da conexão testou no 2026; as outras versões são beta)" : ""), Estado = 2 });

            bool claude = Sistema.ClaudeInstalado();
            r.Add(new Item { Titulo = "Claude para computador", Detalhe = claude ? "encontrado" : "Não encontrei. Baixe em claude.ai/download, abra uma vez e depois clique em Instalar.", Estado = claude ? 2 : 4 });

            bool node = File.Exists(Sistema.Node), idx = File.Exists(Sistema.Index);
            r.Add(new Item
            {
                Titulo = "Conexão baixada (Node.js + servidor)",
                Detalhe = node && idx ? Sistema.Raiz : (!node ? "Falta o Node.js." : "Falta o servidor da conexão."),
                Estado = node && idx ? 2 : 4,
                Acao = "Instalar", Consertar = node && idx ? (Action)null : () => Instalar()
            });

            var faltam = bons.Where(c => !File.Exists(Path.Combine(Sistema.Bundle, @"Contents\" + c.Ano + @"\Civil3DMcpPlugin.dll"))).ToList();
            bool pc = File.Exists(Path.Combine(Sistema.Bundle, "PackageContents.xml"));
            r.Add(new Item
            {
                Titulo = "Plugin montado para o Civil 3D",
                Detalhe = pc && faltam.Count == 0 ? "carrega sozinho quando o Civil 3D abre" : "Falta o plugin" + (faltam.Count > 0 ? " para " + string.Join(", ", faltam.Select(c => c.Nome)) : "") + ".",
                Estado = pc && faltam.Count == 0 ? 2 : 4,
                Acao = "Montar", Consertar = pc && faltam.Count == 0 ? (Action)null : () => Instalar()
            });

            var porta = Environment.GetEnvironmentVariable("CIVIL3D_MCP_PORT", EnvironmentVariableTarget.User);
            bool portaOk = porta == Sistema.Porta.ToString();
            r.Add(new Item
            {
                Titulo = "Porta do plugin (" + Sistema.Porta + ")",
                Detalhe = portaOk ? "configurada (a 8080 fica livre para o Revit)" : "Não configurada. Sem ela o plugin usa a 8080 e não conversa com o Claude.",
                Estado = portaOk ? 2 : 4,
                Acao = "Consertar",
                Consertar = portaOk ? (Action)null : () =>
                {
                    Environment.SetEnvironmentVariable("CIVIL3D_MCP_PORT", Sistema.Porta.ToString(), EnvironmentVariableTarget.User);
                    MessageBox.Show(this, "Porta configurada. Feche e abra o Civil 3D de novo.", "AutoCivil", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MostrarDiagnostico();
                }
            });

            List<string> quebrados; var cfgs = Sistema.LerConfigs(out quebrados);
            foreach (var q in quebrados)
            {
                var arq = q;
                r.Add(new Item
                {
                    Titulo = "Arquivo de configuração do Claude com erro",
                    Detalhe = arq + " tem um erro de digitação (JSON). Enquanto não for corrigido, nenhuma conexão do Claude funciona.",
                    Estado = 4, Acao = "Abrir arquivo",
                    Consertar = () => { try { Process.Start("notepad.exe", "\"" + arq + "\""); } catch { } }
                });
            }
            bool ligado = cfgs.Values.Any(Sistema.ConfigTemCivil);
            r.Add(new Item
            {
                Titulo = "Claude ligado ao Civil 3D",
                Detalhe = ligado ? "a conexão \"civil3d\" está na configuração do Claude" : (node && idx ? "A conexão não está na configuração do Claude." : "Instale a conexão primeiro."),
                Estado = ligado ? 2 : 4,
                Acao = "Ligar",
                Consertar = ligado || !(node && idx) ? (Action)null : () =>
                {
                    var erros = new List<string>();
                    Sistema.FecharClaude();
                    int n = Sistema.GravarConfig(erros);
                    Log.Gravar("ligar: " + n + " config(s); erros: " + string.Join(" | ", erros));
                    if (n == 0) { MessageBox.Show(this, "Não consegui gravar a configuração.\n" + string.Join("\n", erros), "AutoCivil", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                    System.Threading.Thread.Sleep(1500);
                    Sistema.AbrirClaude(_caminhoClaude);
                    MessageBox.Show(this, "Pronto. O Claude foi reiniciado com a conexão do Civil 3D.", "AutoCivil", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MostrarDiagnostico();
                }
            });

            bool aberto = Sistema.CivilAberto();
            bool resp = Sistema.PortaAberta(Sistema.Porta);
            r.Add(new Item
            {
                Titulo = "Plugin respondendo agora",
                Detalhe = resp ? "o Civil 3D está aberto e o plugin está ouvindo na porta " + Sistema.Porta
                    : aberto ? "O Civil 3D está aberto, mas o plugin não respondeu. Se você abriu o Civil 3D antes de instalar, feche e abra de novo. Senão, digite C3DMCPSTART na linha de comando (e clique em \"Sempre carregar\" se aparecer o aviso)."
                    : "O Civil 3D está fechado. Abra o Civil 3D com um desenho e clique em \"Verificar de novo\".",
                Estado = resp ? 2 : 3
            });
            Log.Gravar("diagnóstico: " + string.Join("; ", r.Select(i => i.Titulo + "=" + i.Estado)));
            return r;
        }
    }
}
