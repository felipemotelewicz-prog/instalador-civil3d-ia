#!/bin/sh
# Compila o AutoCivil.exe (.NET Framework 4.8) com o compilador do Mono.
cd "$(dirname "$0")" && mkdir -p out && mcs -sdk:4.8 -target:winexe -optimize+ -out:out/AutoCivil.exe -win32icon:autocivil.ico \
 -r:System.Windows.Forms.dll -r:System.Drawing.dll -r:System.Web.Extensions.dll -r:System.Core.dll \
 -resource:completo.ps1,completo.ps1 -resource:autocivil.ico,autocivil.ico -resource:logo.png,logo.png \
 -resource:fontes/Geist-Regular.ttf,Geist-Regular.ttf -resource:fontes/Geist-Light.ttf,Geist-Light.ttf -resource:fontes/GeistMono-Regular.ttf,GeistMono-Regular.ttf \
 Program.cs AssemblyInfo.cs
